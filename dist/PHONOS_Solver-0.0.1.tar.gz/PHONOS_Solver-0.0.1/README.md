# PHONOS (PytHON sOlver Sudoku)
Hi, it's an extension to solve Sudoku using backtracking algorithm in Python. WIP

 - [x] Core of the project
 - [x] MRV algorithm
 - [x] Degree algorithm
 - [x] LCV algorithm
 - [x] Backtracking algorithm
 - [ ] GUI
 
 ## Licence
You can use and modify my code as you want
